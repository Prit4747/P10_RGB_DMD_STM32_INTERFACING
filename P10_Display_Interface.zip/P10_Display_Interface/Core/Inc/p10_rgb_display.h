/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : p10_rgb_display.h
  * @brief          : Header file for P10 RGB LED Display Driver
  ******************************************************************************
  * @attention
  *
  * This file contains the P10 RGB LED display driver definitions and function
  * prototypes for interfacing with P10 32x16 RGB LED modules.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __P10_RGB_DISPLAY_H
#define __P10_RGB_DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <string.h>

/* Exported types ------------------------------------------------------------*/

/* P10 Display Configuration Structure */
typedef struct {
    uint16_t width;          // Display width in pixels
    uint16_t height;         // Display height in pixels
    uint8_t scan_lines;      // Number of scan lines (typically 8 for P10, 16 for larger displays)
    uint8_t color_depth;     // Color depth in bits (8-bit per color)
    uint32_t refresh_rate;   // Refresh rate in Hz
    uint16_t panel_width;    // Individual panel width (32 for standard P10)
    uint16_t panel_height;   // Individual panel height (16 for standard P10)
    uint8_t panels_x;        // Number of panels horizontally
    uint8_t panels_y;        // Number of panels vertically
    uint16_t clock_delay_us; // Clock pulse delay in microseconds
    uint16_t display_delay_us; // Display row delay in microseconds
} P10_Config_t;

/* RGB Color Structure */
typedef struct {
    uint8_t r;  // Red component (0-255)
    uint8_t g;  // Green component (0-255)
    uint8_t b;  // Blue component (0-255)
} RGB_Color_t;

/* Display Buffer Structure */
typedef struct {
    uint8_t *framebuffer;    // Pointer to frame buffer
    uint32_t buffer_size;    // Buffer size in bytes (changed from uint16_t to uint32_t)
    uint8_t current_row;     // Current scanning row
    uint8_t brightness;      // Global brightness (0-255)
    P10_Config_t *config;    // Pointer to display configuration
} P10_Buffer_t;

/* Font Structure for Text Display */
typedef struct {
    const uint8_t *data;     // Font data array
    uint8_t width;           // Character width
    uint8_t height;          // Character height
    uint8_t first_char;      // First character in font
    uint8_t last_char;       // Last character in font
} Font_t;

/* Exported constants --------------------------------------------------------*/

/* P10 Display Dimensions - Default values for single panel */
#define P10_PANEL_WIDTH     32
#define P10_PANEL_HEIGHT    16
#define P10_DEFAULT_SCAN_LINES  8
#define P10_COLOR_DEPTH     8

/* GPIO Pin Definitions - Modify according to your hardware connections */
/* Row Select Pins (A, B, C, D) - D pin needed for displays with 16+ scan lines */
#define ROW_A_PIN           GPIO_PIN_0
#define ROW_A_PORT          GPIOA
#define ROW_B_PIN           GPIO_PIN_1
#define ROW_B_PORT          GPIOA
#define ROW_C_PIN           GPIO_PIN_2
#define ROW_C_PORT          GPIOA
#define ROW_D_PIN           GPIO_PIN_6    // Additional address line for larger displays
#define ROW_D_PORT          GPIOA

/* Control Pins */
#define OE_PIN              GPIO_PIN_3    // Output Enable (Active Low)
#define OE_PORT             GPIOA
#define LAT_PIN             GPIO_PIN_4    // Latch
#define LAT_PORT            GPIOA
#define CLK_PIN             GPIO_PIN_5    // Clock
#define CLK_PORT            GPIOA

/* RGB Data Pins */
#define R1_PIN              GPIO_PIN_0    // Red 1
#define R1_PORT             GPIOB
#define G1_PIN              GPIO_PIN_1    // Green 1
#define G1_PORT             GPIOB
#define B1_PIN              GPIO_PIN_2    // Blue 1
#define B1_PORT             GPIOB
#define R2_PIN              GPIO_PIN_3    // Red 2
#define R2_PORT             GPIOB
#define G2_PIN              GPIO_PIN_4    // Green 2
#define G2_PORT             GPIOB
#define B2_PIN              GPIO_PIN_5    // Blue 2
#define B2_PORT             GPIOB

/* Color Definitions */
#define COLOR_BLACK         {0, 0, 0}
//#define COLOR_RED           {255, 0, 0}
//#define COLOR_GREEN         {0, 255, 0}
//#define COLOR_BLUE          {0, 0, 255}

#define COLOR_RED           {0, 0, 255}//{255, 0, 0}
#define COLOR_GREEN         {0, 255, 0}
#define COLOR_BLUE          {255, 0, 0} //{0, 0, 255}

#define COLOR_WHITE         {255, 255, 255}
#define COLOR_YELLOW        {255, 255, 0}
#define COLOR_MAGENTA       {255, 0, 255}
#define COLOR_CYAN          {0, 255, 255}

/* Timing Constants - Adjusted for larger displays */
#define DISPLAY_REFRESH_RATE    100     // Hz
#define PWM_FREQUENCY           1000    // Hz for brightness control
#define LATCH_PULSE_WIDTH       2       // microseconds (increased for larger displays)
#define CLOCK_PULSE_WIDTH       2       // microseconds (increased for larger displays)
#define ROW_DISPLAY_TIME        200     // microseconds (increased for larger displays)

/* Exported macro ------------------------------------------------------------*/

/* GPIO Control Macros */
#define SET_ROW_SELECT(row) do { \
    HAL_GPIO_WritePin(ROW_A_PORT, ROW_A_PIN, (row & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(ROW_B_PORT, ROW_B_PIN, (row & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(ROW_C_PORT, ROW_C_PIN, (row & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(ROW_D_PORT, ROW_D_PIN, (row & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET); \
} while(0)

#define LATCH_PULSE() do { \
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_SET); \
    HAL_Delay(1); \
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_RESET); \
} while(0)

#define CLOCK_PULSE() do { \
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_SET); \
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET); \
} while(0)

#define OUTPUT_ENABLE(state) \
    HAL_GPIO_WritePin(OE_PORT, OE_PIN, (state) ? GPIO_PIN_RESET : GPIO_PIN_SET)

/* Exported functions prototypes ---------------------------------------------*/

/* Initialization Functions */
HAL_StatusTypeDef P10_Init(P10_Config_t *config);
HAL_StatusTypeDef P10_Buffer_Init(P10_Buffer_t *buffer);
void P10_GPIO_Init(void);

/* Display Control Functions */
void P10_Clear_Display(P10_Buffer_t *buffer);
void P10_Fill_Display(P10_Buffer_t *buffer, RGB_Color_t color);
void P10_Set_Pixel(P10_Buffer_t *buffer, uint16_t x, uint16_t y, RGB_Color_t color);
RGB_Color_t P10_Get_Pixel(P10_Buffer_t *buffer, uint16_t x, uint16_t y);
void P10_Set_Brightness(P10_Buffer_t *buffer, uint8_t brightness);

/* Display Update Functions */
void P10_Update_Display(P10_Buffer_t *buffer);
void P10_Scan_Row(P10_Buffer_t *buffer, uint8_t row);
void P10_Refresh_Display(P10_Buffer_t *buffer);

/* Graphics Functions */
void P10_Draw_Line(P10_Buffer_t *buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, RGB_Color_t color);
void P10_Draw_Rectangle(P10_Buffer_t *buffer, uint16_t x, uint16_t y, uint16_t width, uint16_t height, RGB_Color_t color);
void P10_Fill_Rectangle(P10_Buffer_t *buffer, uint16_t x, uint16_t y, uint16_t width, uint16_t height, RGB_Color_t color);
void P10_Draw_Circle(P10_Buffer_t *buffer, uint16_t center_x, uint16_t center_y, uint16_t radius, RGB_Color_t color);

/* Text Functions */
void P10_Draw_Char(P10_Buffer_t *buffer, uint16_t x, uint16_t y, char ch, RGB_Color_t color, Font_t *font);
void P10_Draw_String(P10_Buffer_t *buffer, uint16_t x, uint16_t y, const char *str, RGB_Color_t color, Font_t *font);
void P10_Scroll_Text(P10_Buffer_t *buffer, const char *text, RGB_Color_t color, Font_t *font, int16_t *scroll_pos);

/* Pattern Functions */
void P10_Draw_Pattern_Gradient(P10_Buffer_t *buffer, RGB_Color_t start_color, RGB_Color_t end_color, uint8_t direction);
void P10_Draw_Pattern_Rainbow(P10_Buffer_t *buffer, uint8_t shift);
void P10_Draw_Pattern_Checkerboard(P10_Buffer_t *buffer, RGB_Color_t color1, RGB_Color_t color2, uint8_t size);

/* Utility Functions */
uint32_t P10_Color_To_RGB565(RGB_Color_t color);
RGB_Color_t P10_RGB565_To_Color(uint32_t rgb565);
RGB_Color_t P10_HSV_To_RGB(uint16_t hue, uint8_t saturation, uint8_t value);
uint8_t P10_Apply_Gamma_Correction(uint8_t value);

/* Timer Interrupt Handler */
void P10_Timer_IRQ_Handler(P10_Buffer_t *buffer);

/* Font Data */
extern const Font_t Font_5x7;
extern const Font_t Font_8x8;

#ifdef __cplusplus
}
#endif

#endif /* __P10_RGB_DISPLAY_H */
