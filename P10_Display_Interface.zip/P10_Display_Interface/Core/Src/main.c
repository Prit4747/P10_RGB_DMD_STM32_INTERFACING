/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "p10_rgb_display.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim8;

/* USER CODE BEGIN PV */
volatile uint8_t buffer_busy = 0; // Buffer status flag for interrupt coordination
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM8_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  int32_t dutyCycle = 0;
  int32_t delta = 5;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);

  // --- P10 Display Configuration ---
  P10_Config_t displayConfig = {
    .width = P10_PANEL_WIDTH,
    .height = P10_PANEL_HEIGHT,
    .scan_lines = P10_DEFAULT_SCAN_LINES,
    .color_depth = P10_COLOR_DEPTH,
    .refresh_rate = DISPLAY_REFRESH_RATE,
    // Add explicit parameters for panel configuration
    .panel_width = P10_PANEL_WIDTH,
    .panel_height = P10_PANEL_HEIGHT,
    .panels_x = 1,  // Using 1 panel horizontally
    .panels_y = 1,  // Using 1 panel vertically
    .clock_delay_us = 5,  // Increase clock delay for better stability
    .display_delay_us = 300  // Increase display delay for better visibility
  };

  // --- P10 Display: Static 'HELLO RGB' ---
  const char *Msg1 = "HELLO ";
  int FontWidth = Font_5x7.width + 1; // 5x7 font + 1 pixel spacing
  P10_Buffer_t DisplayBuffer;
  
  // Set DisplayBuffer.config explicitly
  DisplayBuffer.config = &displayConfig;

  // Initialize the P10 display
  if (P10_Init(&displayConfig) != HAL_OK) {
    Error_Handler();
  }
  
  // Initialize the display buffer
  if (P10_Buffer_Init(&DisplayBuffer) != HAL_OK) {
    Error_Handler();
  }

  // First explicitly DISABLE output to reset display state
  OUTPUT_ENABLE(0);  // 0 = Disable output
  HAL_Delay(100);    // Short delay to ensure state change

  // Now explicitly ENABLE output for displaying data
  OUTPUT_ENABLE(1);  // 1 = Enable output (internally inverted in the macro)
  
  // Ensure latch and clock are in proper state
  HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET);
  
  // Set PWM duty cycle to maximum (100%) for maximum brightness
  htim8.Instance->CCR1 = 100;
  
  // Clear buffer with known good state
  P10_Clear_Display(&DisplayBuffer);
  
  // Set brightness to maximum
  P10_Set_Brightness(&DisplayBuffer, 255);

  // Define colors with ABSOLUTE maximum intensity to ensure visibility
  // Define pure, maximum intensity colors for best visibility
  RGB_Color_t Red = COLOR_RED;
  RGB_Color_t Green = COLOR_GREEN;
  RGB_Color_t Blue = COLOR_BLUE;
  RGB_Color_t White = COLOR_WHITE;
  RGB_Color_t Yellow = COLOR_YELLOW;
  RGB_Color_t Magenta = COLOR_MAGENTA;
  RGB_Color_t Cyan = COLOR_CYAN;
  
  // *** DIAGNOSTIC TEST PATTERNS ***
  // Run a series of tests to verify LED functionality
  
  // Test 1: Full panel color tests - light up entire panel in different colors
  // Red test
  //P10_Clear_Display(&DisplayBuffer);
  P10_Fill_Display(&DisplayBuffer, Red);
  P10_Update_Display(&DisplayBuffer);
  HAL_Delay(800);
  
  // Green test
  P10_Clear_Display(&DisplayBuffer);
  P10_Fill_Display(&DisplayBuffer, Green);
  P10_Update_Display(&DisplayBuffer);
  HAL_Delay(800);
  
  // Blue test
  P10_Clear_Display(&DisplayBuffer);
  P10_Fill_Display(&DisplayBuffer, Blue);
  P10_Update_Display(&DisplayBuffer);
  HAL_Delay(800);
  
  // White test
  P10_Clear_Display(&DisplayBuffer);
  P10_Fill_Display(&DisplayBuffer, White);
  P10_Update_Display(&DisplayBuffer);
  HAL_Delay(800);
  
 /* // Test 2: Color cycling animation
  for (int i = 0; i < 3; i++) {
    // Cycle through all basic colors
    RGB_Color_t colors[] = {Red, Green, Blue, Yellow, Cyan, Magenta, White};
    for (int c = 0; c < 7; c++) {
      P10_Clear_Display(&DisplayBuffer);
      P10_Fill_Display(&DisplayBuffer, colors[c]);
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(200); // Faster cycling
    }
  }
  
  // Test 3: Horizontal scanning pattern
  for (uint8_t repeat = 0; repeat < 2; repeat++) {
    // Scan from left to right
    for (uint16_t col = 0; col < displayConfig.width; col++) {
      P10_Clear_Display(&DisplayBuffer);
      for (uint16_t y = 0; y < displayConfig.height; y++) {
        P10_Set_Pixel(&DisplayBuffer, col, y, White);
      }
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(20);
    }
    
    // Scan from right to left
    for (int16_t col = displayConfig.width - 1; col >= 0; col--) {
      P10_Clear_Display(&DisplayBuffer);
      for (uint16_t y = 0; y < displayConfig.height; y++) {
        P10_Set_Pixel(&DisplayBuffer, col, y, White);
      }
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(20);
    }
  }
  
  // Test 4: Vertical scanning pattern
  for (uint8_t repeat = 0; repeat < 2; repeat++) {
    // Scan from top to bottom
    for (uint16_t row = 0; row < displayConfig.height; row++) {
      P10_Clear_Display(&DisplayBuffer);
      for (uint16_t x = 0; x < displayConfig.width; x++) {
        P10_Set_Pixel(&DisplayBuffer, x, row, White);
      }
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(50);
    }
    
    // Scan from bottom to top
    for (int16_t row = displayConfig.height - 1; row >= 0; row--) {
      P10_Clear_Display(&DisplayBuffer);
      for (uint16_t x = 0; x < displayConfig.width; x++) {
        P10_Set_Pixel(&DisplayBuffer, x, row, White);
      }
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(50);
    }
  }
  
  // Test 5: RGB diagonal patterns
  for (uint8_t repeat = 0; repeat < 2; repeat++) {
    // Diagonal from top-left to bottom-right
    for (int16_t pos = -displayConfig.height; pos < displayConfig.width; pos++) {
      P10_Clear_Display(&DisplayBuffer);
      for (uint16_t i = 0; i < displayConfig.height; i++) {
        int16_t x = pos + i;
        if (x >= 0 && x < displayConfig.width) {
          RGB_Color_t color;
          switch (i % 3) {
            case 0: color = Red; break;
            case 1: color = Green; break;
            case 2: color = Blue; break;
          }
          P10_Set_Pixel(&DisplayBuffer, x, i, color);
        }
      }
      P10_Update_Display(&DisplayBuffer);
      HAL_Delay(50);
    }
  }
  
  // Test 6: Checkerboard pattern
  for (uint8_t repeat = 0; repeat < 4; repeat++) {
    P10_Clear_Display(&DisplayBuffer);
    
    // Create a checkerboard pattern alternating between two colors
    RGB_Color_t color1 = (repeat % 2 == 0) ? White : Magenta;
    RGB_Color_t color2 = (repeat % 2 == 0) ? Magenta : White;
    
    for (uint16_t y = 0; y < displayConfig.height; y++) {
      for (uint16_t x = 0; x < displayConfig.width; x++) {
        if ((x + y) % 2 == 0) {
          P10_Set_Pixel(&DisplayBuffer, x, y, color1);
        } else {
          P10_Set_Pixel(&DisplayBuffer, x, y, color2);
        }
      }
    }
    P10_Update_Display(&DisplayBuffer);
    HAL_Delay(500);
  }
  
  // Test 7: Border pattern - draws a border in different colors
  for (int c = 0; c < 3; c++) {
    RGB_Color_t borderColor;
    switch (c) {
      case 0: borderColor = Red; break;
      case 1: borderColor = Green; break;
      case 2: borderColor = Blue; break;
    }
    
    P10_Clear_Display(&DisplayBuffer);
    // Draw a border around the display
    // Top and bottom lines
    for (uint16_t x = 0; x < displayConfig.width; x++) {
      P10_Set_Pixel(&DisplayBuffer, x, 0, borderColor);
      P10_Set_Pixel(&DisplayBuffer, x, displayConfig.height - 1, borderColor);
    }
    // Left and right lines
    for (uint16_t y = 0; y < displayConfig.height; y++) {
      P10_Set_Pixel(&DisplayBuffer, 0, y, borderColor);
      P10_Set_Pixel(&DisplayBuffer, displayConfig.width - 1, y, borderColor);
    }
    P10_Update_Display(&DisplayBuffer);
    HAL_Delay(500);
  }
  
  // Test 8: Text scrolling test - "RGB" scrolling across the display
  const char *testText = "RGB";
  int textWidth = strlen(testText) * FontWidth;
  for (int16_t x = displayConfig.width; x > -textWidth; x--) {
    P10_Clear_Display(&DisplayBuffer);
    
    // Draw each character with its own color
    P10_Draw_Char(&DisplayBuffer, x, 4, 'R', Red, (Font_t*)&Font_5x7);
    P10_Draw_Char(&DisplayBuffer, x + FontWidth, 4, 'G', Green, (Font_t*)&Font_5x7);
    P10_Draw_Char(&DisplayBuffer, x + 2*FontWidth, 4, 'B', Blue, (Font_t*)&Font_5x7);
    
    P10_Update_Display(&DisplayBuffer);
    HAL_Delay(50);
  }*/
  
  // Clear display before starting main loop
  P10_Clear_Display(&DisplayBuffer);
  P10_Update_Display(&DisplayBuffer);
  HAL_Delay(500);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    // Set PWM duty cycle to maximum for brightness
    htim8.Instance->CCR1 = 100;
    
    // Clear the display buffer first
    P10_Clear_Display(&DisplayBuffer);

    // Ensure output is enabled
    OUTPUT_ENABLE(1);
    
    // Calculate positions to place HELLO in upper half and RGB in lower half
    
    // Upper half position for "HELLO" - position close to the top
    int y_pos_hello = 0;  // 1 pixel from the top
    
    // Lower half position for "RGB" - place it in the bottom half
    // For a 16-pixel height display, position around 9 or 10
    int y_pos_rgb = displayConfig.height / 2 ;  // 2 pixels below the middle
    
    // Draw 'HELLO ' in RED starting at position (0, y_pos_hello)
    P10_Draw_String(&DisplayBuffer, 0, y_pos_hello, Msg1, Red, (Font_t*)&Font_5x7);
    
    // Position for RGB letters - start from left side for better visibility
    int x_position_rgb = 0;  // Start from left side 
    
    // Draw 'R', 'G', 'B' in their respective colors in the lower half
    P10_Draw_Char(&DisplayBuffer, x_position_rgb, y_pos_rgb, 'R', Red, (Font_t*)&Font_5x7);
    P10_Draw_Char(&DisplayBuffer, x_position_rgb + FontWidth, y_pos_rgb, 'G', Green, (Font_t*)&Font_5x7);
    P10_Draw_Char(&DisplayBuffer, x_position_rgb + 2*FontWidth, y_pos_rgb, 'B', Blue, (Font_t*)&Font_5x7);
    
    // Update the display with the new buffer contents
    P10_Update_Display(&DisplayBuffer);
    
    // Ensure output remains enabled after update
    OUTPUT_ENABLE(1);
    
    // Allow time for the display to stabilize - longer delay for stable display
    HAL_Delay(1);
    
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */
  // Enable TIM2 update interrupt
  HAL_TIM_Base_Start_IT(&htim2);
  
  // Enable TIM2 interrupt in NVIC
  HAL_NVIC_SetPriority(TIM2_IRQn, 1, 0);  // Lower priority than TIM3
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 83;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 124;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 24;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 100;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA4 PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB3
                           PB4 PB5 PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
