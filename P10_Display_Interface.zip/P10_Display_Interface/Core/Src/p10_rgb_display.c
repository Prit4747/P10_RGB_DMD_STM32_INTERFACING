/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : p10_rgb_display.c
  * @brief          : P10 RGB LED Display Driver Implementation
  ******************************************************************************
  * @attention
  *
  * This file contains the implementation of P10 RGB LED display driver
  * functions for STM32F407 microcontroller.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "p10_rgb_display.h"
#include "main.h"
#include <stdlib.h>
#include <math.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define GAMMA_CORRECTION_ENABLED    1
#define PWM_LEVELS                  16    // Number of PWM levels for brightness

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static P10_Config_t display_config;
static uint8_t gamma_table[256];
static volatile uint8_t current_pwm_level = 0;

/* 5x7 Font Data */
static const uint8_t font_5x7_data[] = {
    // Space (32)
    0x00, 0x00, 0x00, 0x00, 0x00,
    // ! (33)
    0x00, 0x00, 0x5F, 0x00, 0x00,
    // " (34)
    0x00, 0x07, 0x00, 0x07, 0x00,
    // # (35)
    0x14, 0x7F, 0x14, 0x7F, 0x14,
    // $ (36)
    0x24, 0x2A, 0x7F, 0x2A, 0x12,
    // % (37)
    0x23, 0x13, 0x08, 0x64, 0x62,
    // & (38)
    0x36, 0x49, 0x55, 0x22, 0x50,
    // ' (39)
    0x00, 0x05, 0x03, 0x00, 0x00,
    // ( (40)
    0x00, 0x1C, 0x22, 0x41, 0x00,
    // ) (41)
    0x00, 0x41, 0x22, 0x1C, 0x00,
    // * (42)
    0x08, 0x2A, 0x1C, 0x2A, 0x08,
    // + (43)
    0x08, 0x08, 0x3E, 0x08, 0x08,
    // , (44)
    0x00, 0x50, 0x30, 0x00, 0x00,
    // - (45)
    0x08, 0x08, 0x08, 0x08, 0x08,
    // . (46)
    0x00, 0x60, 0x60, 0x00, 0x00,
    // / (47)
    0x20, 0x10, 0x08, 0x04, 0x02,
    // 0 (48)
    0x3E, 0x51, 0x49, 0x45, 0x3E,
    // 1 (49)
    0x00, 0x42, 0x7F, 0x40, 0x00,
    // 2 (50)
    0x42, 0x61, 0x51, 0x49, 0x46,
    // 3 (51)
    0x21, 0x41, 0x45, 0x4B, 0x31,
    // 4 (52)
    0x18, 0x14, 0x12, 0x7F, 0x10,
    // 5 (53)
    0x27, 0x45, 0x45, 0x45, 0x39,
    // 6 (54)
    0x3C, 0x4A, 0x49, 0x49, 0x30,
    // 7 (55)
    0x01, 0x71, 0x09, 0x05, 0x03,
    // 8 (56)
    0x36, 0x49, 0x49, 0x49, 0x36,
    // 9 (57)
    0x06, 0x49, 0x49, 0x29, 0x1E,
    // : (58)
    0x00, 0x36, 0x36, 0x00, 0x00,
    // ; (59)
    0x00, 0x56, 0x36, 0x00, 0x00,
    // < (60)
    0x00, 0x08, 0x14, 0x22, 0x41,
    // = (61)
    0x14, 0x14, 0x14, 0x14, 0x14,
    // > (62)
    0x41, 0x22, 0x14, 0x08, 0x00,
    // ? (63)
    0x02, 0x01, 0x51, 0x09, 0x06,
    // @ (64)
    0x32, 0x49, 0x79, 0x41, 0x3E,
    // A (65)
    0x7E, 0x11, 0x11, 0x11, 0x7E,
    // B (66)
    0x7F, 0x49, 0x49, 0x49, 0x36,
    // C (67)
    0x3E, 0x41, 0x41, 0x41, 0x22,
    // D (68)
    0x7F, 0x41, 0x41, 0x22, 0x1C,
    // E (69)
    0x7F, 0x49, 0x49, 0x49, 0x41,
    // F (70)
    0x7F, 0x09, 0x09, 0x01, 0x01,
    // G (71)
    0x3E, 0x41, 0x41, 0x51, 0x32,
    // H (72)
    0x7F, 0x08, 0x08, 0x08, 0x7F,
    // I (73)
    0x00, 0x41, 0x7F, 0x41, 0x00,
    // J (74)
    0x20, 0x40, 0x41, 0x3F, 0x01,
    // K (75)
    0x7F, 0x08, 0x14, 0x22, 0x41,
    // L (76)
    0x7F, 0x40, 0x40, 0x40, 0x40,
    // M (77)
    0x7F, 0x02, 0x04, 0x02, 0x7F,
    // N (78)
    0x7F, 0x04, 0x08, 0x10, 0x7F,
    // O (79)
    0x3E, 0x41, 0x41, 0x41, 0x3E,
    // P (80)
    0x7F, 0x09, 0x09, 0x09, 0x06,
    // Q (81)
    0x3E, 0x41, 0x51, 0x21, 0x5E,
    // R (82)
    0x7F, 0x09, 0x19, 0x29, 0x46,
    // S (83)
    0x46, 0x49, 0x49, 0x49, 0x31,
    // T (84)
    0x01, 0x01, 0x7F, 0x01, 0x01,
    // U (85)
    0x3F, 0x40, 0x40, 0x40, 0x3F,
    // V (86)
    0x1F, 0x20, 0x40, 0x20, 0x1F,
    // W (87)
    0x7F, 0x20, 0x18, 0x20, 0x7F,
    // X (88)
    0x63, 0x14, 0x08, 0x14, 0x63,
    // Y (89)
    0x03, 0x04, 0x78, 0x04, 0x03,
    // Z (90)
    0x61, 0x51, 0x49, 0x45, 0x43
};

const Font_t Font_5x7 = {
    .data = font_5x7_data,
    .width = 5,
    .height = 7,
    .first_char = 32,
    .last_char = 90
};

/* Private function prototypes -----------------------------------------------*/
static void P10_Init_Gamma_Table(void);
static void P10_Shift_RGB_Data(uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2);
static void P10_Shift_RGB_Data_Config(P10_Config_t *config, uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2);
static uint32_t P10_Get_Buffer_Index(P10_Buffer_t *buffer, uint16_t x, uint16_t y);
static void P10_Delay_us(uint32_t us);

/* Function implementations --------------------------------------------------*/

/**
  * @brief  Initialize P10 display with configuration
  * @param  config: Pointer to P10 configuration structure
  * @retval HAL status
  */
HAL_StatusTypeDef P10_Init(P10_Config_t *config)
{
    if (config == NULL) {
        return HAL_ERROR;
    }
    
    // Copy configuration
    display_config = *config;
    
    // Initialize GPIO pins
    P10_GPIO_Init();
    
    // Initialize gamma correction table
    P10_Init_Gamma_Table();
    
    // Set initial state
    OUTPUT_ENABLE(0);  // Disable output initially
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET);
    SET_ROW_SELECT(0);
    
    return HAL_OK;
}

/**
  * @brief  Initialize display buffer
  * @param  buffer: Pointer to buffer structure
  * @retval HAL status
  */
HAL_StatusTypeDef P10_Buffer_Init(P10_Buffer_t *buffer)
{
    if (buffer == NULL || buffer->config == NULL) {
        return HAL_ERROR;
    }
    
    // Calculate buffer size based on configuration
    buffer->buffer_size = buffer->config->width * buffer->config->height * 3; // RGB buffer
    
    // Allocate frame buffer memory
    buffer->framebuffer = (uint8_t*)malloc(buffer->buffer_size);
    if (buffer->framebuffer == NULL) {
        return HAL_ERROR;
    }
    
    buffer->current_row = 0;
    buffer->brightness = 255;  // Full brightness
    
    // Clear the buffer
    P10_Clear_Display(buffer);
    
    return HAL_OK;
}

/**
  * @brief  Initialize GPIO pins for P10 display
  * @param  None
  * @retval None
  */
void P10_GPIO_Init(void)
{
    // GPIO initialization is already done in main.c
    // This function can be used for any additional GPIO configuration
    
    // Ensure all control pins are in known state
    HAL_GPIO_WritePin(OE_PORT, OE_PIN, GPIO_PIN_SET);    // Output disabled
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_RESET); // Latch low
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET); // Clock low
    
    // Set row select to 0
    SET_ROW_SELECT(0);
    
    // Clear all RGB data pins
    HAL_GPIO_WritePin(R1_PORT, R1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G1_PORT, G1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B1_PORT, B1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(R2_PORT, R2_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G2_PORT, G2_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B2_PORT, B2_PIN, GPIO_PIN_RESET);
}

/**
  * @brief  Clear the display buffer
  * @param  buffer: Pointer to buffer structure
  * @retval None
  */
void P10_Clear_Display(P10_Buffer_t *buffer)
{
    if (buffer && buffer->framebuffer) {
        memset(buffer->framebuffer, 0, buffer->buffer_size);
    }
}

/**
  * @brief  Fill display with solid color
  * @param  buffer: Pointer to buffer structure
  * @param  color: RGB color to fill
  * @retval None
  */
void P10_Fill_Display(P10_Buffer_t *buffer, RGB_Color_t color)
{
    if (!buffer || !buffer->framebuffer || !buffer->config) return;
    
    for (uint16_t y = 0; y < buffer->config->height; y++) {
        for (uint16_t x = 0; x < buffer->config->width; x++) {
            P10_Set_Pixel(buffer, x, y, color);
        }
    }
}

/**
  * @brief  Set pixel color at specific coordinates
  * @param  buffer: Pointer to buffer structure
  * @param  x: X coordinate
  * @param  y: Y coordinate
  * @param  color: RGB color
  * @retval None
  */
void P10_Set_Pixel(P10_Buffer_t *buffer, uint16_t x, uint16_t y, RGB_Color_t color)
{
    if (!buffer || !buffer->framebuffer || !buffer->config) return;
    if (x >= buffer->config->width || y >= buffer->config->height) return;
    
    uint32_t index = P10_Get_Buffer_Index(buffer, x, y);
    
    #if GAMMA_CORRECTION_ENABLED
    buffer->framebuffer[index] = gamma_table[color.r];
    buffer->framebuffer[index + 1] = gamma_table[color.g];
    buffer->framebuffer[index + 2] = gamma_table[color.b];
    #else
    buffer->framebuffer[index] = color.r;
    buffer->framebuffer[index + 1] = color.g;
    buffer->framebuffer[index + 2] = color.b;
    #endif
}

/**
  * @brief  Get pixel color at specific coordinates
  * @param  buffer: Pointer to buffer structure
  * @param  x: X coordinate
  * @param  y: Y coordinate
  * @retval RGB color
  */
RGB_Color_t P10_Get_Pixel(P10_Buffer_t *buffer, uint16_t x, uint16_t y)
{
    RGB_Color_t color = {0, 0, 0};
    
    if (!buffer || !buffer->framebuffer || !buffer->config) return color;
    if (x >= buffer->config->width || y >= buffer->config->height) return color;
    
    uint32_t index = P10_Get_Buffer_Index(buffer, x, y);
    
    color.r = buffer->framebuffer[index];
    color.g = buffer->framebuffer[index + 1];
    color.b = buffer->framebuffer[index + 2];
    
    return color;
}

/**
  * @brief  Set global brightness
  * @param  buffer: Pointer to buffer structure
  * @param  brightness: Brightness level (0-255)
  * @retval None
  */
void P10_Set_Brightness(P10_Buffer_t *buffer, uint8_t brightness)
{
    if (buffer) {
        buffer->brightness = brightness;
    }
}

/**
  * @brief  Update display with current buffer content
  * @param  buffer: Pointer to buffer structure
  * @retval None
  */
void P10_Update_Display(P10_Buffer_t *buffer)
{
    if (!buffer || !buffer->framebuffer || !buffer->config) return;
    
    for (uint8_t row = 0; row < buffer->config->scan_lines; row++) {
        P10_Scan_Row(buffer, row);
    }
}

/**
  * @brief  Scan single row of display
  * @param  buffer: Pointer to buffer structure
  * @param  row: Row number to scan
  * @retval None
  */
void P10_Scan_Row(P10_Buffer_t *buffer, uint8_t row)
{
    if (!buffer || !buffer->framebuffer || !buffer->config) return;
    if (row >= buffer->config->scan_lines) return;
    
    // Disable output during data loading
    OUTPUT_ENABLE(0);
    
    // Set row address - use config to determine if D line is needed
    if (buffer->config->scan_lines > 8) {
        // For displays with more than 8 scan lines, use all 4 address lines
        HAL_GPIO_WritePin(ROW_A_PORT, ROW_A_PIN, (row & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(ROW_B_PORT, ROW_B_PIN, (row & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(ROW_C_PORT, ROW_C_PIN, (row & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(ROW_D_PORT, ROW_D_PIN, (row & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    } else {
        // Standard 8-line configuration
        SET_ROW_SELECT(row);
    }
    
    // Shift data for this row
    for (uint16_t col = 0; col < buffer->config->width; col++) {
        // Get pixel data for upper and lower half
        RGB_Color_t pixel1 = P10_Get_Pixel(buffer, col, row);
        RGB_Color_t pixel2 = P10_Get_Pixel(buffer, col, row + buffer->config->scan_lines);
        
        // Apply brightness scaling
        uint8_t r1 = (pixel1.r * buffer->brightness) >> 8;
        uint8_t g1 = (pixel1.g * buffer->brightness) >> 8;
        uint8_t b1 = (pixel1.b * buffer->brightness) >> 8;
        uint8_t r2 = (pixel2.r * buffer->brightness) >> 8;
        uint8_t g2 = (pixel2.g * buffer->brightness) >> 8;
        uint8_t b2 = (pixel2.b * buffer->brightness) >> 8;
        
        // Shift RGB data with configurable timing
        P10_Shift_RGB_Data_Config(buffer->config, r1, g1, b1, r2, g2, b2);
    }
    
    // Latch data with configurable timing
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_SET);
    P10_Delay_us(buffer->config->clock_delay_us);
    HAL_GPIO_WritePin(LAT_PORT, LAT_PIN, GPIO_PIN_RESET);
    
    // Enable output
    OUTPUT_ENABLE(1);
    
    // Display time - use configurable delay for larger displays
    P10_Delay_us(buffer->config->display_delay_us);
}

/**
  * @brief  Refresh display continuously
  * @param  buffer: Pointer to buffer structure
  * @retval None
  */
void P10_Refresh_Display(P10_Buffer_t *buffer)
{
    // This function should be called from timer interrupt
    if (!buffer || !buffer->config) return;
    
    P10_Scan_Row(buffer, buffer->current_row);
    
    buffer->current_row++;
    if (buffer->current_row >= buffer->config->scan_lines) {
        buffer->current_row = 0;
    }
}

/**
  * @brief  Draw line between two points
  * @param  buffer: Pointer to buffer structure
  * @param  x0, y0: Start coordinates
  * @param  x1, y1: End coordinates
  * @param  color: Line color
  * @retval None
  */
void P10_Draw_Line(P10_Buffer_t *buffer, uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, RGB_Color_t color)
{
    int16_t dx = abs(x1 - x0);
    int16_t dy = abs(y1 - y0);
    int16_t sx = x0 < x1 ? 1 : -1;
    int16_t sy = y0 < y1 ? 1 : -1;
    int16_t err = dx - dy;
    
    int16_t x = x0, y = y0;
    
    while (1) {
        P10_Set_Pixel(buffer, x, y, color);
        
        if (x == x1 && y == y1) break;
        
        int16_t e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x += sx;
        }
        if (e2 < dx) {
            err += dx;
            y += sy;
        }
    }
}

/**
  * @brief  Draw rectangle outline
  * @param  buffer: Pointer to buffer structure
  * @param  x, y: Top-left coordinates
  * @param  width, height: Rectangle dimensions
  * @param  color: Rectangle color
  * @retval None
  */
void P10_Draw_Rectangle(P10_Buffer_t *buffer, uint16_t x, uint16_t y, uint16_t width, uint16_t height, RGB_Color_t color)
{
    P10_Draw_Line(buffer, x, y, x + width - 1, y, color);                    // Top
    P10_Draw_Line(buffer, x, y + height - 1, x + width - 1, y + height - 1, color); // Bottom
    P10_Draw_Line(buffer, x, y, x, y + height - 1, color);                  // Left
    P10_Draw_Line(buffer, x + width - 1, y, x + width - 1, y + height - 1, color);  // Right
}

/**
  * @brief  Fill rectangle with solid color
  * @param  buffer: Pointer to buffer structure
  * @param  x, y: Top-left coordinates
  * @param  width, height: Rectangle dimensions
  * @param  color: Fill color
  * @retval None
  */
void P10_Fill_Rectangle(P10_Buffer_t *buffer, uint16_t x, uint16_t y, uint16_t width, uint16_t height, RGB_Color_t color)
{
    if (!buffer || !buffer->config) return;
    
    for (uint16_t py = y; py < y + height && py < buffer->config->height; py++) {
        for (uint16_t px = x; px < x + width && px < buffer->config->width; px++) {
            P10_Set_Pixel(buffer, px, py, color);
        }
    }
}

/**
  * @brief  Draw character using specified font
  * @param  buffer: Pointer to buffer structure
  * @param  x, y: Character position
  * @param  ch: Character to draw
  * @param  color: Character color
  * @param  font: Font to use
  * @retval None
  */
void P10_Draw_Char(P10_Buffer_t *buffer, uint16_t x, uint16_t y, char ch, RGB_Color_t color, Font_t *font)
{
    if (!buffer || !font || !font->data || !buffer->config) return;
    
    if (ch < font->first_char || ch > font->last_char) return;
    
    uint8_t char_index = ch - font->first_char;
    const uint8_t *char_data = &font->data[char_index * font->width];
    
    for (uint8_t col = 0; col < font->width; col++)
    {
        uint8_t column_data = char_data[col];
        for (uint8_t row = 0; row < font->height; row++)
        {
            if (column_data & (1 << row))
            {
                if (x + col < buffer->config->width && y + row < buffer->config->height)
                {
                    P10_Set_Pixel(buffer, x + col, y + row, color);
                }
            }
        }
    }
}

/**
  * @brief  Draw string using specified font
  * @param  buffer: Pointer to buffer structure
  * @param  x, y: String position
  * @param  str: String to draw
  * @param  color: String color
  * @param  font: Font to use
  * @retval None
  */
void P10_Draw_String(P10_Buffer_t *buffer, uint16_t x, uint16_t y, const char *str, RGB_Color_t color, Font_t *font)
{
    if (!buffer || !str || !font || !buffer->config) return;
    
    uint16_t pos_x = x;
    
    while (*str && pos_x < buffer->config->width) {
        P10_Draw_Char(buffer, pos_x, y, *str, color, font);
        pos_x += font->width + 1;  // Add spacing between characters
        str++;
    }
}

/**
  * @brief  Scroll text horizontally
  * @param  buffer: Pointer to buffer structure
  * @param  text: Text to scroll
  * @param  color: Text color
  * @param  font: Font to use
  * @param  scroll_pos: Current scroll position (updated by function)
  * @retval None
  */
void P10_Scroll_Text(P10_Buffer_t *buffer, const char *text, RGB_Color_t color, Font_t *font, int16_t *scroll_pos)
{
    if (!buffer || !text || !font || !scroll_pos || !buffer->config) return;
    
    P10_Clear_Display(buffer);
    P10_Draw_String(buffer, *scroll_pos, 4, text, color, font);
    
    (*scroll_pos)--;
    
    // Reset position when text scrolls off screen
    int16_t text_width = strlen(text) * (font->width + 1);
    if (*scroll_pos < -text_width) {
        *scroll_pos = buffer->config->width;
    }
}

/**
  * @brief  Draw rainbow pattern
  * @param  buffer: Pointer to buffer structure
  * @param  shift: Rainbow shift value
  * @retval None
  */
void P10_Draw_Pattern_Rainbow(P10_Buffer_t *buffer, uint8_t shift)
{
    if (!buffer || !buffer->config) return;
    
    for (uint16_t x = 0; x < buffer->config->width; x++) {
        for (uint16_t y = 0; y < buffer->config->height; y++) {
            uint16_t hue = (x * 360 / buffer->config->width + shift) % 360;
            RGB_Color_t color = P10_HSV_To_RGB(hue, 255, 255);
            P10_Set_Pixel(buffer, x, y, color);
        }
    }
}

/**
  * @brief  Convert HSV to RGB color
  * @param  hue: Hue (0-359)
  * @param  saturation: Saturation (0-255)
  * @param  value: Value/Brightness (0-255)
  * @retval RGB color
  */
RGB_Color_t P10_HSV_To_RGB(uint16_t hue, uint8_t saturation, uint8_t value)
{
    RGB_Color_t rgb = {0, 0, 0};
    
    if (saturation == 0) {
        rgb.r = rgb.g = rgb.b = value;
        return rgb;
    }
    
    uint8_t region = hue / 60;
    uint8_t remainder = (hue - (region * 60)) * 6;
    
    uint8_t p = (value * (255 - saturation)) >> 8;
    uint8_t q = (value * (255 - ((saturation * remainder) >> 8))) >> 8;
    uint8_t t = (value * (255 - ((saturation * (255 - remainder)) >> 8))) >> 8;
    
    switch (region) {
        case 0: rgb.r = value; rgb.g = t; rgb.b = p; break;
        case 1: rgb.r = q; rgb.g = value; rgb.b = p; break;
        case 2: rgb.r = p; rgb.g = value; rgb.b = t; break;
        case 3: rgb.r = p; rgb.g = q; rgb.b = value; break;
        case 4: rgb.r = t; rgb.g = p; rgb.b = value; break;
        default: rgb.r = value; rgb.g = p; rgb.b = q; break;
    }
    
    return rgb;
}

/**
  * @brief  Timer interrupt handler for display refresh
  * @param  buffer: Pointer to buffer structure
  * @retval None
  */
void P10_Timer_IRQ_Handler(P10_Buffer_t *buffer)
{
    // Update PWM level for temporal dithering (reduces flickering)
    current_pwm_level = (current_pwm_level + 16) % 256;
    
    // Refresh one row of the display
    P10_Refresh_Display(buffer);
}

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Initialize gamma correction lookup table
  * @param  None
  * @retval None
  */
static void P10_Init_Gamma_Table(void)
{
    for (int i = 0; i < 256; i++) {
        gamma_table[i] = (uint8_t)(pow((float)i / 255.0, 2.2) * 255.0 + 0.5);
    }
}

/**
  * @brief  Shift RGB data to display shift registers
  * @param  r1, g1, b1: RGB values for upper half
  * @param  r2, g2, b2: RGB values for lower half
  * @retval None
  */
static void P10_Shift_RGB_Data(uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2)
{
    // Use multiple thresholds for improved color perception and reduced flickering
    // This creates more consistent color representation
    
    // Using 4 levels per color instead of simple on/off
    HAL_GPIO_WritePin(R1_PORT, R1_PIN, (r1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G1_PORT, G1_PIN, (g1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B1_PORT, B1_PIN, (b1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(R2_PORT, R2_PIN, (r2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G2_PORT, G2_PIN, (g2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B2_PORT, B2_PIN, (b2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    
    // Clock pulse to shift data - add a small delay to ensure stable signal
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_SET);
    P10_Delay_us(1);  // Short but critical delay
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET);
}

/**
  * @brief  Shift RGB data to display shift registers with configurable timing
  * @param  config: Pointer to P10 configuration structure
  * @param  r1, g1, b1: RGB values for upper half
  * @param  r2, g2, b2: RGB values for lower half
  * @retval None
  */
static void P10_Shift_RGB_Data_Config(P10_Config_t *config, uint8_t r1, uint8_t g1, uint8_t b1, uint8_t r2, uint8_t g2, uint8_t b2)
{
    // Using 4 levels per color instead of simple on/off
    HAL_GPIO_WritePin(R1_PORT, R1_PIN, (r1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G1_PORT, G1_PIN, (g1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B1_PORT, B1_PIN, (b1 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(R2_PORT, R2_PIN, (r2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(G2_PORT, G2_PIN, (g2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(B2_PORT, B2_PIN, (b2 > current_pwm_level) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    
    // Clock pulse to shift data - add a small delay to ensure stable signal
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_SET);
    P10_Delay_us(config->clock_delay_us);
    HAL_GPIO_WritePin(CLK_PORT, CLK_PIN, GPIO_PIN_RESET);
}

/**
  * @brief  Get buffer index for pixel coordinates
  * @param  buffer: Pointer to buffer structure
  * @param  x: X coordinate
  * @param  y: Y coordinate
  * @retval Buffer index
  */
static uint32_t P10_Get_Buffer_Index(P10_Buffer_t *buffer, uint16_t x, uint16_t y)
{
    return (y * buffer->config->width + x) * 3;  // 3 bytes per pixel (RGB)
}

/**
  * @brief  Microsecond delay
  * @param  us: Delay in microseconds
  * @retval None
  */
static void P10_Delay_us(uint32_t us)
{
    // Simple delay implementation
    // For more accurate timing, use hardware timer
    volatile uint32_t count = us * (SystemCoreClock / 1000000) / 4;
    while (count--);
}